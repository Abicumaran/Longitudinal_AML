library(affy)
library(limma)
library(AnnotationDbi)
library(hgu133plus2.db)

# Set working directory
setwd("C:/Users/uabic/Desktop")

# Read the CEL files
Data <- ReadAffy(celfile.path = "Data")

# Perform RMA normalization
eset <- rma(Data)

# Define sample groups
sample_info <- setNames(
  c(rep("T", 33), rep("N", 5)),  # Number of T and N adjusted as per total files
  c(
    "GSM187698.CEL", "GSM187701.CEL", "GSM187704.CEL", "GSM187707.CEL",
    "GSM187710.CEL", "GSM187713.CEL", "GSM187716.CEL", "GSM187719.CEL",
    "GSM187722.CEL", "GSM187725.CEL", "GSM187728.CEL", "GSM187731.CEL",
    "GSM187734.CEL", "GSM187737.CEL", "GSM187740.CEL", "GSM187743.CEL",
    "GSM187746.CEL", "GSM187749.CEL", "GSM187752.CEL", "GSM187755.CEL",
    "GSM187758.CEL", "GSM187761.CEL", "GSM187764.CEL", "GSM187767.CEL",
    "GSM187770.CEL", "GSM187771.CEL", "GSM187772.CEL", "GSM187780.CEL",
    "GSM187781.CEL", "GSM187782.CEL", "GSM187788.CEL", "GSM187789.CEL",
    "GSM187790.CEL",
    "GSM100895.CEL", "GSM100896.CEL", "GSM100897.CEL", "GSM100898.CEL",
    "GSM100901.CEL"
  )
)

sample_groups <- ifelse(names(sample_info) %in% c(
  "GSM100895.CEL", "GSM100896.CEL", "GSM100897.CEL", "GSM100898.CEL",
  "GSM100901.CEL"), "N", "T")

pData(eset)$group <- factor(sample_groups, levels = c("N", "T"))

# Extract expression matrix
expr_matrix <- exprs(eset)
write.csv(expr_matrix,"expr.csv")

# Read the expression data
expr_data <- read.csv("expr.csv", stringsAsFactors = FALSE)

# Extract probe IDs and ensure they are character type
probe_ids <- as.character(expr_data$PROBE_ID)

# Map probe IDs to gene symbols, handling 1:many mappings by selecting the first match
gene_info <- select(hgu133plus2.db, keys = probe_ids, columns = "SYMBOL", keytype = "PROBEID")

# Handle 1:many mappings by keeping only the first occurrence for each probe ID
gene_info <- gene_info[!duplicated(gene_info$PROBEID), ]

# Check for any mismatch in row numbers after handling duplicates
if (length(probe_ids) != nrow(gene_info)) {
  warning("Mismatch in rows after handling duplicates.")
}

# Add probe IDs to gene_info for correct merging
gene_info$PROBE_ID <- probe_ids[match(gene_info$PROBEID, probe_ids)]

# Merge gene symbols back to expression data
merged_data <- merge(expr_data, gene_info, by = "PROBE_ID")

# Replace PROBE_ID with gene SYMBOL in the merged data
merged_data$PROBE_ID <- merged_data$SYMBOL

# Write the aggregated data to a new CSV file
write.csv(merged_data, "merged_expr.csv", row.names = FALSE)
