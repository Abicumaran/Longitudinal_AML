library(affy)
setwd("C:/Users/uabic/Desktop")

# Load necessary libraries
library(tools)
library(limma)

# Read the CEL files from the directory "Data"
Data <- ReadAffy(celfile.path = "Data")

# Perform RMA normalization
eset <- rma(Data)

# Explicitly define each sample and its group
sample_info <- setNames(
  c(rep("T", 33), rep("N", 5)),  # Number of T and N adjusted as per total files
  c(
    "GSM187698.CEL", "GSM187701.CEL", "GSM187704.CEL", "GSM187707.CEL",
    "GSM187710.CEL", "GSM187713.CEL", "GSM187716.CEL", "GSM187719.CEL",
    "GSM187722.CEL", "GSM187725.CEL", "GSM187728.CEL", "GSM187731.CEL",
    "GSM187734.CEL", "GSM187737.CEL", "GSM187740.CEL", "GSM187743.CEL",
    "GSM187746.CEL", "GSM187749.CEL", "GSM187752.CEL", "GSM187755.CEL",
    "GSM187758.CEL", "GSM187761.CEL", "GSM187764.CEL", "GSM187767.CEL",
    "GSM187770.CEL", "GSM187771.CEL", "GSM187772.CEL", "GSM187780.CEL",
    "GSM187781.CEL", "GSM187782.CEL", "GSM187788.CEL", "GSM187789.CEL",
    "GSM187790.CEL",
    "GSM100895.CEL", "GSM100896.CEL", "GSM100897.CEL", "GSM100898.CEL",
    "GSM100901.CEL"
  )
)

# Assign "N" to specific samples, rest are "T"
sample_groups <- ifelse(names(sample_info) %in% c(
  "GSM100895.CEL", "GSM100896.CEL", "GSM100897.CEL", "GSM100898.CEL",
  "GSM100901.CEL"), "N", "T")

# Set the sample information in the ExpressionSet object
pData(eset)$group <- factor(sample_groups, levels = c("N", "T"))

# Create the design matrix for control (N) and treatment (T)
design <- model.matrix(~ group, data = pData(eset))

# Fit the linear model using limma
fit <- lmFit(eset, design)

# Apply empirical Bayes smoothing
fit <- eBayes(fit)

# Get the top differentially expressed genes
results <- topTable(fit, adjust="BH", sort.by="P", number=Inf)

# Optionally, save the results to a file
write.table(results, file="DEGs.txt", sep="\t", quote=FALSE, row.names=TRUE)

# View the results
print(results)

library(AnnotationDbi)
library(hgu133plus2.db)  # Load the library for Human Genome U133 Plus 2.0 Array

# Assuming DEG data is available
# Load the data
data <- read.csv("DEG.csv", stringsAsFactors = FALSE)

# Extract probe IDs from the first column which is expected to be named 'Gene'
probe_ids <- data$Gene

# Map probe IDs to gene symbols, ENTREZ IDs, and gene names
gene_info <- tryCatch({
  select(hgu133plus2.db, keys = probe_ids, columns = c("SYMBOL", "ENTREZID", "GENENAME"), keytype = "PROBEID")
}, error = function(e) {
  message("Error mapping probe IDs: ", e$message)
  NULL  # Returns NULL if an error occurs
})

# Check if mapping was successful
if (is.null(gene_info)) {
  message("Failed to retrieve gene information. Check probe IDs and database selection.")
} else {
  message("Mapping successful, proceeding with merging data.")
}

# Print a snippet of the mapped data
head(gene_info)
# Merge the gene information with the DEG data
merged_data <- merge(data, gene_info, by.x = "Gene", by.y = "PROBEID", all.x = TRUE)

# Replace the Gene column with SYMBOL if available
merged_data$Gene <- ifelse(is.na(merged_data$SYMBOL), merged_data$Gene, merged_data$SYMBOL)
merged_data$SYMBOL <- NULL  # Optionally remove the now redundant SYMBOL column

# Save the updated data to a new CSV file
write.csv(merged_data, "updated_DEG_data.csv", row.names = FALSE)

# View the updated data frame
head(merged_data)
