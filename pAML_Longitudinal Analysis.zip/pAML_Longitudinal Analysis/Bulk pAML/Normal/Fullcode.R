# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(igraph)
library(reshape2)
library(ggplot2)
library(minet)

# Read the subset CSV
subset_df <- read_csv('subset2.csv')

# Normalize the data (excluding the first column which contains gene names)
numeric_data <- subset_df %>% select(-Gene) %>% as.matrix()
normalized_data <- scale(numeric_data)

# Combine the normalized data with the gene names
normalized_df <- subset_df %>% 
  select(Gene) %>% 
  bind_cols(as.data.frame(normalized_data))

# Transpose the normalized data to get genes as columns
transposed_normalized_data <- t(normalized_data)
colnames(transposed_normalized_data) <- subset_df$Gene

# Generate adjacency matrix with Pearson correlation (genes by genes)
pearson_adj <- cor(transposed_normalized_data)

# Save the Pearson correlation adjacency matrix
write.csv(pearson_adj, 'pearson_adjacency_matrix.csv', row.names = TRUE)

# Generate adjacency matrix with mutual information (genes by genes)
# Discretize the data
library(infotheo)
discretized_data <- discretize(transposed_normalized_data, nbins = 5)

# Compute the mutual information matrix
mi_matrix <- mutinformation(discretized_data, method = "emp")

# Save the mutual information adjacency matrix
write.csv(mi_matrix, 'mi_adjacency_matrix.csv', row.names = TRUE)

# Convert adjacency matrices to long format for visualization
pearson_long <- melt(pearson_adj)
colnames(pearson_long) <- c("Gene1", "Gene2", "Correlation")
mi_long <- melt(mi_matrix)
colnames(mi_long) <- c("Gene1", "Gene2", "MutualInformation")

# Filter the top 100 values for Pearson correlation and mutual information
top_pearson <- pearson_long %>% 
  filter(Gene1 != Gene2) %>% 
  arrange(desc(abs(Correlation))) %>% 
  slice(1:100)

top_mi <- mi_long %>% 
  filter(Gene1 != Gene2) %>% 
  arrange(desc(MutualInformation)) %>% 
  slice(1:100)

# Save the top 100 Pearson correlation and mutual information values
write.csv(top_pearson, 'top_100_pearson.csv', row.names = FALSE)
write.csv(top_mi, 'top_100_mi.csv', row.names = FALSE)

# Visualize the top 50 genes with highest Pearson correlation
top_50_pearson <- top_pearson %>% slice(1:50)
ggplot(top_50_pearson, aes(x = reorder(Gene1, -abs(Correlation)), y = Correlation, fill = abs(Correlation))) +
  geom_bar(stat = 'identity') +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Top 50 Genes with Highest Pearson Correlation", x = "Genes", y = "Pearson Correlation") +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2))

# Save the Pearson correlation plot
ggsave("top_50_pearson_plot.png")

# Visualize the top 50 genes with highest Mutual Information
top_50_mi <- top_mi %>% slice(1:50)
ggplot(top_50_mi, aes(x = reorder(Gene1, -MutualInformation), y = MutualInformation, fill = MutualInformation)) +
  geom_bar(stat = 'identity') +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Top 50 Genes with Highest Mutual Information", x = "Genes", y = "Mutual Information") +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2))

# Save the Mutual Information plot
ggsave("top_50_mi_plot.png")

# Prepare data for heatmap
pearson_genes <- unique(c(top_50_pearson$Gene1, top_50_pearson$Gene2))
mi_genes <- unique(c(top_50_mi$Gene1, top_50_mi$Gene2))

pearson_heatmap_data <- pearson_adj[pearson_genes, pearson_genes]
mi_heatmap_data <- mi_matrix[mi_genes, mi_genes]

# Create and save Pearson correlation heatmap
library(pheatmap)
pheatmap(pearson_heatmap_data,
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         show_rownames = TRUE,
         show_colnames = TRUE,
         main = "Top 50 Pearson Correlation Heatmap")

# Save the Pearson correlation heatmap
ggsave("top_50_pearson_heatmap.png", width = 10, height = 10)

# Create and save mutual information heatmap
pheatmap(mi_heatmap_data,
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         show_rownames = TRUE,
         show_colnames = TRUE,
         main = "Top 50 Mutual Information Heatmap")

# Save the Mutual Information heatmap
ggsave("top_50_mi_heatmap.png", width = 10, height = 10)

print("Normalization, adjacency matrix creation, and visualization complete!")


#ADDITIONAL ANALYSIS
# Generate adjacency matrix with Spearman correlation (genes by genes)
spearman_adj <- cor(transposed_normalized_data, method = "spearman")

# Save the Spearman correlation adjacency matrix
write.csv(spearman_adj, 'spearman_adjacency_matrix.csv', row.names = TRUE)

# Generate adjacency matrix with Kendall Tau correlation (genes by genes)
kendall_adj <- cor(transposed_normalized_data, method = "kendall")

# Save the Kendall Tau correlation adjacency matrix
write.csv(kendall_adj, 'kendall_adjacency_matrix.csv', row.names = TRUE)

library(corpcor)
library(huge)

# Generate adjacency matrix with partial correlation (genes by genes)
partial_corr_matrix <- cor2pcor(cor(transposed_normalized_data))
colnames(partial_corr_matrix) <- colnames(transposed_normalized_data)
rownames(partial_corr_matrix) <- colnames(transposed_normalized_data)

# Save the partial correlation adjacency matrix
write.csv(partial_corr_matrix, 'partial_correlation_adjacency_matrix.csv', row.names = TRUE)

# Generate adjacency matrix with Graphical Lasso (genes by genes)
glasso_fit <- huge(as.matrix(transposed_normalized_data), method = "glasso")
glasso_adj <- glasso_fit$icov[[1]] # Choose the first lambda value
colnames(glasso_adj) <- colnames(transposed_normalized_data)
rownames(glasso_adj) <- colnames(transposed_normalized_data)

# Save the Graphical Lasso adjacency matrix
write.csv(glasso_adj, 'glasso_adjacency_matrix.csv', row.names = TRUE)

# Function to create heatmap for the top 20 genes in an adjacency matrix
create_heatmap_top20 <- function(adj_matrix, title, filename) {
  # Calculate the degree centrality (sum of connections)
  degree_centrality <- rowSums(adj_matrix) + colSums(adj_matrix)
  
  # Select the top 20 nodes based on degree centrality
  top20_genes <- names(sort(degree_centrality, decreasing = TRUE))[1:20]
  
  # Subset the adjacency matrix to only include the top 20 nodes
  top20_adj_matrix <- adj_matrix[top20_genes, top20_genes]
  
  # Create and save the heatmap
  p <- pheatmap(top20_adj_matrix,
                cluster_rows = TRUE,
                cluster_cols = TRUE,
                show_rownames = TRUE,
                show_colnames = TRUE,
                main = title)
  ggsave(filename, plot = p, width = 10, height = 10)
}


# Function to create heatmap for the top 20 genes in an adjacency matrix
create_heatmap_top20 <- function(adj_matrix, title, filename) {
  # Calculate the degree centrality (sum of connections)
  degree_centrality <- rowSums(adj_matrix) + colSums(adj_matrix)
  
  # Get unique gene names and their degree centrality
  unique_genes <- unique(names(degree_centrality))
  unique_degree_centrality <- degree_centrality[unique_genes]
  
  # Select the top 20 unique nodes based on degree centrality
  top20_genes <- names(sort(unique_degree_centrality, decreasing = TRUE))[1:20]
  
  # Subset the adjacency matrix to only include the top 20 unique nodes
  top20_adj_matrix <- adj_matrix[top20_genes, top20_genes]
  
  # Create and save the heatmap
  p <- pheatmap(top20_adj_matrix,
                cluster_rows = TRUE,
                cluster_cols = TRUE,
                show_rownames = TRUE,
                show_colnames = TRUE,
                main = title)
  ggsave(filename, plot = p, width = 10, height = 10)
}

# Create and save heatmaps for each method
create_heatmap_top20(pearson_adj, "Top 20 Pearson Correlation Heatmap", "top20_pearson_correlation_heatmap.png")
create_heatmap_top20(spearman_adj, "Top 20 Spearman Correlation Heatmap", "top20_spearman_correlation_heatmap.png")
create_heatmap_top20(kendall_adj, "Top 20 Kendall Tau Correlation Heatmap", "top20_kendall_tau_correlation_heatmap.png")
create_heatmap_top20(partial_corr_matrix, "Top 20 Partial Correlation Heatmap", "top20_partial_correlation_heatmap.png")
create_heatmap_top20(glasso_adj, "Top 20 Graphical Lasso Heatmap", "top20_glasso_heatmap.png")

print("Network inference and heatmap creation complete!")

